import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Vector;

public class MyFileReader {
	static private Map<String,Cities> AllCities = new HashMap<String,Cities>();
	static public void getOutput(String cin, int option) {
		if(option == 1 || (option == 8)) {
			System.out.print("The temperature in " + cin + " is " + AllCities.get(cin).getCurrtemp() + " degrees Fahrenheit.");
		}
		if(option == 2 || option == 8) {
			System.out.print("The high temperature in " + cin + " is " + AllCities.get(cin).getDayHigh() + " degrees Fahrenheit.");
			System.out.print("The low temperature in " + cin + " is " + AllCities.get(cin).getDayLow() + " degrees Fahrenheit.");
		}
		if(option == 3 || option == 8) {
			System.out.print("The humidity in " + cin + " is " + AllCities.get(cin).getHumidity() + "%.");
		}
		if(option == 4 || option == 8) {
			System.out.print("The pressure in " + cin + " is " + AllCities.get(cin).getPressure() + " Inch Hg.");
		}
		if(option == 5 || option == 8) {
			System.out.print("The visibility in " + cin + " is " + AllCities.get(cin).getVisibility() + " miles.");
		}
		if(option == 6 || option == 8) {
			System.out.print("The wind speed in " + cin + " is " + AllCities.get(cin).getWindspeed() + " miles/hour. \n");
			System.out.print("The wind direction in " + cin + " is " + AllCities.get(cin).getWindDir() + " degrees.");
		}
		if(option == 7 || option == 8) {
			System.out.print(cin + " weather can be described as");
			for(int i = 0; i<AllCities.get(cin).getConditions().size(); i++) {
				System.out.print(AllCities.get(cin).getConditions().get(i));
				System.out.print(", ");
			}
			System.out.print("\n");
		}
		if(option == 9) {
			return;
		}
	}
	
	public static void main(String [] args) {
		//asking for the name of the file
		System.out.print("What is the name of the weather file? ");
		Scanner scan = new Scanner(System.in);
		String filename = scan.nextLine();
		System.out.println("filename = " + filename);
		scan.close();
		
		try { //DEAL WITH EXCEPTIONS
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			//go through every line (all cities)
			while(line != null) {
				Cities currCity = new Cities();
				Vector<String> temp = new Vector<String>();
				String split[] = line.split("|");
				//check if the size of split is enough THROW
				//set all variables
				//check if the variables are the type they are supposed to be THROW
				currCity.setName(split[0].toLowerCase());
				currCity.setCurrtemp(Integer.parseInt(split[1]));
				currCity.setDayLow(Integer.parseInt(split[2]));
				currCity.setDayHigh(Integer.parseInt(split[3]));
				currCity.setHumidity(Integer.parseInt(split[4]));
				currCity.setPressure(Float.parseFloat(split[5]));
				currCity.setVisibility(Float.parseFloat(split[6]));
				currCity.setWindspeed(Float.parseFloat(split[7]));
				currCity.setWindDir(Integer.parseInt(split[8]));
				for(int i = 9; i< split.length; i++) {
					temp.add(split[i].toLowerCase());
				}
				currCity.setConditions(temp);
				//adding current city to set of cities
				AllCities.put(split[0].toLowerCase(), currCity);
			}
			br.close();
			fr.close();
		}catch(FileNotFoundException fnfe) {
			System.out.println("fnfe: " + fnfe.getMessage());		
		}catch(IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
		//prompt user for what city they want the information
		while(2 == 2) {
			System.out.print("For what city would you like weather information? ");
			Scanner reader = new Scanner(System.in);
			String UserCity = reader.nextLine();
			reader.close();
			if(UserCity == "exit") {
				System.out.print("Thank you for usint my weather program.");
				return;
			}
			if(AllCities.containsKey(UserCity) || UserCity.toLowerCase() == "all") {
				if(UserCity.toLowerCase() == "all") {
					System.out.print("I do have information about the weather in all cities. ");
				}
				else {
					System.out.print("I do have information about the weather in " + UserCity);
				}
				System.out.print("1) Temperature \n2) High and low temperature today \n3) Humidity \n4) Pressure \n5) Visibility \n6) Wind speed and direction"
					+ "\n7)Descriptions of weather conditions \n8) Everything \n9) Enter a different city");
				System.out.print("What information would you like to know?");
				Scanner user = new Scanner(System.in);
				int option = user.nextInt();
				user.close();
				if(UserCity.toLowerCase() == "all") {
					for(String key : AllCities.keySet()) {
						getOutput(key,option);
					}
					getOutput(UserCity.toLowerCase(), option);
				}
				else {
					getOutput(UserCity.toLowerCase(), option);
				}
			}
		}
		
	}

}
