

import java.io.IOException;
import java.util.Collections;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Cities
 */
@WebServlet("/Cities")
public class Cities extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String name;
	private int currtemp;
	private int dayLow;
	private int dayHigh;
	private int humidity;
	private float pressure;
	private float visibility;
	private float windspeed;
	private int windDir;
	private Vector<String> conditions = new Vector<String>();
	//set and find the city's name
	public void setName(String n) {
		this.name = n;
	}
	public String getName() {
		return name;
	}
	//set and find current temperature
	public void setCurrtemp(int n) {
		this.currtemp = n;
	}
	public int getCurrtemp() {
		return currtemp;
	}
	//set and find daylow
	public void setDayLow(int n) {
		this.dayLow = n;
	}
	public int getDayLow() {
		return dayLow;
	}
	//set and find day high
	public void setDayHigh(int n) {
		this.dayHigh = n;
	}
	public int getDayHigh() {
		return dayHigh;
	}
	//set and find the humidity
	public void setHumidity(int n) {
		this.humidity = n;
	}
	public int getHumidity() {
		return humidity;
	}
	//set and find the pressure
	public void setPressure(float n) {
		this.pressure = n;
	}
	public float getPressure() {
		return pressure;
	}
	//set and find visibility
	public void setVisibility(float n) {
		this.visibility = n;
	}
	public float getVisibility() {
		return visibility;
	}
	//set and find windspeed
	public void setWindspeed(float n) {
		this.windspeed = n;
	}
	public float getWindspeed() {
		return windspeed;
	}
	//set and find windDir
	public void setWindDir(int n) {
		this.windDir = n;
	}
	public int getWindDir() {
		return windDir;
	}
	//set and find conditions
	public void setConditions(Vector<String> n) {
		
		conditions.setSize(n.size());
		Collections.copy(conditions, n);
	}
	public Vector<String> getConditions() {
		return conditions;
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cities() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
