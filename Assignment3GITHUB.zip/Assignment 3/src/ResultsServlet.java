

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import hw2.Cities2;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import hw2.MyFileReader;
import hw2.OpenWeather;

/**
 * Servlet implementation class ResultsServlet
 */
@WebServlet("/ResultsServlet")
public class ResultsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	MyFileReader w = new MyFileReader();
	 ArrayList<Cities2> arr = w.getAllCities();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResultsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ID = request.getParameter("I");
		Integer identification = Integer.parseInt(ID);
		
		String weblink = "http://api.openweathermap.org/data/2.5/weather?id="+identification + "&appid=39488d49cf22baba75bd6f4bac7f5c6f";
			URL openweather = new URL(weblink);
	        URLConnection ow = openweather.openConnection();
	        BufferedReader in = new BufferedReader(new InputStreamReader(ow.getInputStream()));
	      	Gson gson = new Gson();
			OpenWeather AllWeather = gson.fromJson(in, OpenWeather.class);
			
		@SuppressWarnings("unused")
		String key = (String) request.getParameter("link");
		request.setAttribute("Name",AllWeather.getName());
		request.setAttribute("Country",AllWeather.getSys().getCountry());
		request.setAttribute("Latitude",AllWeather.getCoord().getLat());
		request.setAttribute("Longitude",AllWeather.getCoord().getLon());
		request.setAttribute("Sunrise",AllWeather.getSys().getSunrise());
		request.setAttribute("Sunset",AllWeather.getSys().getSunset());
		request.setAttribute("CurrTemp",AllWeather.getMain().getTemp());
		request.setAttribute("TempLow",AllWeather.getMain().getTempMin());
		request.setAttribute("TempHigh",AllWeather.getMain().getTempMax());
		request.setAttribute("Humidity",AllWeather.getMain().getPressure());
		request.setAttribute("Pressure",AllWeather.getMain().getHumidity());
		request.setAttribute("Windspeed",AllWeather.getWind().getSpeed());
		request.setAttribute("WindDir",AllWeather.getWind().getDeg());
		
		//send in number of cities
		//go to weather page
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/weather.jsp");
		dispatch.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
