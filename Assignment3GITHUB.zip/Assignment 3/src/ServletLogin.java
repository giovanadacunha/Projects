

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hw2.Database;

/**
 * Servlet implementation class ServletLogin
 */
@WebServlet("/ServletLogin")
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Database db = new Database();
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String Password = request.getParameter("pass");
		if(username.contentEquals("") || Password.contentEquals("") ) {
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/login.jsp");
			dispatch.forward(request,response);
		}
		else if(!db.CheckUser(username)) {
			request.setAttribute("taken", "no");
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/login.jsp");
			dispatch.forward(request,response);
		}
		else if(db.LoginUser(username,Password) == -1) {
			request.setAttribute("matches", "no");
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/login.jsp");
			dispatch.forward(request,response);
		}
		else {
			System.out.println("checking userWORKED");

			HttpSession session = request.getSession();
			request.setAttribute("recent", "true");
			session.setAttribute("UserId", db.GetID(username));
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/index.jsp");
			dispatch.forward(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
