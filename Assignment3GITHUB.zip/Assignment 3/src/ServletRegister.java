

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hw2.Database;

/**
 * Servlet implementation class ServletRegister
 */
@WebServlet("/ServletRegister")
public class ServletRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletRegister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Database db = new Database();
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String Password = request.getParameter("pass");
		String CPassword = request.getParameter("confirmpass");
		if(username.contentEquals("") || Password.contentEquals("") || CPassword.contentEquals("")) {
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/register.jsp");
			dispatch.forward(request,response);
		}
		if(!Password.contentEquals(CPassword)) {
			request.setAttribute("same", "error");
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/register.jsp");
			dispatch.forward(request,response);
		}
		else if(db.CheckUser(username)) {
			request.setAttribute("taken", "yes");
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/register.jsp");
			dispatch.forward(request,response);
		}
		else if(!db.CheckUser(username)) {
			db.RegisterUser(username, Password);
			request.setAttribute("recent", "registered");
			HttpSession session = request.getSession();
			session.setAttribute("UserId", db.GetID(username));
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/index.jsp");
			dispatch.forward(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
