

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hw2.OpenWeather;

/**
 * Servlet implementation class ServletSort
 */
@WebServlet("/ServletSort")
public class ServletSort extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletSort() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		@SuppressWarnings("unchecked")
		ArrayList<OpenWeather> OWarr = (ArrayList<OpenWeather>)session.getAttribute("ARRAYSS");
		String value = request.getParameter("selectbox");
		 if(value.contentEquals("AZ")){
			  request.setAttribute("sort", "AZ");
		  }
		  else if(value.contentEquals("ZA")) {
			  request.setAttribute("sort", "ZA");
		  }
		  else if(value.contentEquals("LASC")) {
			  request.setAttribute("sort", "LASC");
		  }
		  else if(value.contentEquals("LDESC")) {
			  request.setAttribute("sort", "LDESC");
		  }
		  else if(value.contentEquals("HASC")) {
			  request.setAttribute("sort", "HASC");
		  }
		  else if(value.contentEquals("HDESC")) {
			  request.setAttribute("sort", "HDESC");
		  }
		 request.setAttribute("input", "sort");
		 session.setAttribute("ARRAYSS", OWarr);
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/results.jsp");
		dispatch.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
