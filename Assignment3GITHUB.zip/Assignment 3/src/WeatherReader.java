

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
class TooFewParametersException extends Exception{
	public TooFewParametersException(String message) {
		super(message);
	}
}
@SuppressWarnings("serial")
class NotFormattedProperlyException extends Exception{
	public NotFormattedProperlyException(String message) {
		super(message);
	}
}
@SuppressWarnings("serial")
class UnableToConvertException extends Exception{
	public UnableToConvertException(String message) {
		super(message);
	}
}
@SuppressWarnings("serial")
class NotValidOptionException extends Exception{
	public NotValidOptionException(String message) {
		super(message);
	}
}
@SuppressWarnings("serial")
class UnableToFindCityException extends Exception{
	public UnableToFindCityException(String message) {
		super(message);
	}
}
/**
 * Servlet implementation class WeatherReader
 */
@WebServlet("/WeatherReader")
public class WeatherReader extends HttpServlet {
	public int isitok = 0;
	static public Map<String,Cities> AllCities = new HashMap<String,Cities>();
	static public void getOutput(String cin, int option) {
		if(option == 1 || (option == 8)) {
			System.out.println("The temperature in " + cin + " is " + AllCities.get(cin).getCurrtemp() + " degrees Fahrenheit.");
		}
		if(option == 2 || option == 8) {
			System.out.println("The high temperature in " + cin + " is " + AllCities.get(cin).getDayHigh() + " degrees Fahrenheit.");
			System.out.println("The low temperature in " + cin + " is " + AllCities.get(cin).getDayLow() + " degrees Fahrenheit.");
		}
		if(option == 3 || option == 8) {
			System.out.println("The humidity in " + cin + " is " + AllCities.get(cin).getHumidity() + "%.");
		}
		if(option == 4 || option == 8) {
			System.out.println("The pressure in " + cin + " is " + AllCities.get(cin).getPressure() + " Inch Hg.");
		}
		if(option == 5 || option == 8) {
			System.out.println("The visibility in " + cin + " is " + AllCities.get(cin).getVisibility() + " miles.");
		}
		if(option == 6 || option == 8) {
			System.out.println("The wind speed in " + cin + " is " + AllCities.get(cin).getWindspeed() + " miles/hour.");
			System.out.println("The wind direction in " + cin + " is " + AllCities.get(cin).getWindDir() + " degrees.");
		}
		//NOT WORKING
		if(option == 7 || option == 8) {
			System.out.print(cin + " weather can be described as ");
			for(int i = 0; i<AllCities.get(cin).getConditions().size(); i++) {
				System.out.print(AllCities.get(cin).getConditions().get(i));
				if(i<AllCities.get(cin).getConditions().size()-2) {
					System.out.print(", ");
				}
				if(i==AllCities.get(cin).getConditions().size()-2) {
					System.out.print(" and ");
				}
			}
			System.out.print(".\n");
		}
		if(option == 9) {
			return;
		}
	}
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WeatherReader(String filename) {
    	boolean done = false;
		while(!done) {
			int n = 0;
			String temporary = new String();
			try {
				FileReader fr = new FileReader(filename);
				BufferedReader br = new BufferedReader(fr);
				String line = br.readLine();
				//go through every line (all cities)
				while(line != null) {
					Cities currCity = new Cities();
					Vector<String> temp = new Vector<String>();
		
					for(char a:line.toCharArray()) {
						if(a != '|') {
							temporary += a;
						}
						else {
							System.out.println(temporary);
							if(n == 0) {
								currCity.setName(temporary.toLowerCase());
							}
							if(n == 1) {
								currCity.setCurrtemp(Integer.parseInt(temporary));
							}
							if(n == 2) {
								currCity.setDayLow(Integer.parseInt(temporary));
							}
							if(n == 3) {
								currCity.setDayHigh(Integer.parseInt(temporary));
							}
							if(n == 4) {
								currCity.setHumidity(Integer.parseInt(temporary));
							}
							if(n == 5) {
								currCity.setPressure(Float.parseFloat(temporary));
							}
							if(n == 6) {
								currCity.setVisibility(Float.parseFloat(temporary));
							}
							if(n == 7) {
								currCity.setWindspeed(Float.parseFloat(temporary));
							}
							if(n==8) {
								currCity.setWindDir(Integer.parseInt(temporary));
							}
							if(n>8) {
								temp.add(temporary.toLowerCase());
							}
							n++;
							temporary = new String();
						}
						
					}
					if(!temporary.equals("") && !temporary.equals(null)) {
						temp.add(temporary.toLowerCase());
					}
					if(n<9) {
						throw new TooFewParametersException("This file " + filename + " is not formatted properly. \nThere are not enough parameters on line '" + line + "'.");
					}
					currCity.setConditions(temp);
					AllCities.put(currCity.getName(), currCity);
					line = br.readLine();
					n = 0;
					temporary = new String();
				}
				br.close();
				fr.close();
				done = true;
			}catch(FileNotFoundException fnfe) {
				isitok = 1;
				done = true;
				System.out.println("The file " + filename + " could not be found");	
			}catch(IOException ioe) {
				isitok = 1;
				done = true;
				System.out.println("ioe: " + ioe.getMessage());
			}catch(TooFewParametersException tfpe) {
				isitok=1;
				done = true;
				System.out.println(tfpe.getMessage());
			}catch(NumberFormatException ex) {
				isitok=1;
				done = true;
				System.out.println("This file " + filename + " is not formatted properly.");
				System.out.println("n= " + n);
				if(n == 0) {
					System.out.println("Unable to convert 'current temperature=" + temporary + "' to an integer.");
				}
				if(n == 1) {
					System.out.println("Unable to convert 'low temperature=" + temporary + "' to an integer.");
				}
				if(n == 2) {
					System.out.println("Unable to convert 'high temperature=" + temporary + "' to an integer.");
				}
				if(n ==3) {
					System.out.println("Unable to convert 'humidity=" + temporary + "' to an integer.");
				}
				if(n == 4) {
					System.out.println("Unable to convert 'pressure=" + temporary + "' to a float.");
				}
				if(n == 5) {
					System.out.println("Unable to convert 'visibility=" + temporary + "' to a float.");
				}
				if(n == 6) {
					System.out.println("Unable to convert 'wind speed=" + temporary + "' to a float.");
				}
				if(n == 7) {
					System.out.println("Unable to convert 'wind direction=" + temporary + "' to an integer.");
				}
			}
		}
}
        // TODO Auto-generated constructor stub
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
