package hw2;

import java.util.Collections;
import java.util.Vector;

public class City {
	private String name;
	private String state;
	private String country;
	private double longitude;
	private double latitude;
	private String sunset;
	private String sunrise;
	private int currtemp;
	private int dayLow;
	private int dayHigh;
	private int humidity;
	private float pressure;
	private float visibility;
	private float windspeed;
	private int windDir;
	private Vector<String> conditions = new Vector<String>();
	//set and find the city's name
	public void setName(String n) {
		this.name = n;
	}
	public String getName() {
		return name;
	}
	//set and find the city's country
	public void setCountry(String n) {
		this.country = n;
	}
	public String getCountry() {
		return country;
	}
	//set and find city's state
	public void setState(String n) {
		this.state = n;
	}
	public String getState() {
		return state;
	}
	//set and find city's longitude
	public void setLongitude(double n) {
		this.longitude = n;
	}
	public double getLongitude() {
		return longitude;
	}
	//set and find city's longitude
	public void setLatitude(double n) {
		this.latitude = n;
	}
	public double getLatitude() {
		return latitude;
	}
	//set and find city's sunset time
	public void setSunset(String n) {
		this.sunset = n;
	}
	public String getSunset() {
		return sunset;
	}
	//set and find city's sunset time
	public void setSunrise(String n) {
		this.sunrise = n;
	}
	public String getSunrise() {
		return sunrise;
	}
	//set and find current temperature
	public void setCurrtemp(int n) {
		this.currtemp = n;
	}
	public int getCurrtemp() {
		return currtemp;
	}
	//set and find daylow
	public void setDayLow(int n) {
		this.dayLow = n;
	}
	public int getDayLow() {
		return dayLow;
	}
	//set and find day high
	public void setDayHigh(int n) {
		this.dayHigh = n;
	}
	public int getDayHigh() {
		return dayHigh;
	}
	//set and find the humidity
	public void setHumidity(int n) {
		this.humidity = n;
	}
	public int getHumidity() {
		return humidity;
	}
	//set and find the pressure
	public void setPressure(float n) {
		this.pressure = n;
	}
	public float getPressure() {
		return pressure;
	}
	//set and find visibility
	public void setVisibility(float n) {
		this.visibility = n;
	}
	public float getVisibility() {
		return visibility;
	}
	//set and find windspeed
	public void setWindspeed(float n) {
		this.windspeed = n;
	}
	public float getWindspeed() {
		return windspeed;
	}
	//set and find windDir
	public void setWindDir(int n) {
		this.windDir = n;
	}
	public int getWindDir() {
		return windDir;
	}
	//set and find conditions
	public void setConditions(Vector<String> n) {
		
		conditions.setSize(n.size());
		Collections.copy(conditions, n);
	}
	public Vector<String> getConditions() {
		return conditions;
	}
	//ASSIGNMENT 2 NEW FUNCTIONS(2-7);

}