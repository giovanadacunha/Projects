package hw2;

import java.util.Comparator;

public class CityNameAscendingComparator implements Comparator<OpenWeather> {

	@Override
	public int compare(OpenWeather w0, OpenWeather w1) {
		return (w0.getName()+w0.getSys().getCountry()).compareTo(w1.getName()+w1.getSys().getCountry());
	}

}
