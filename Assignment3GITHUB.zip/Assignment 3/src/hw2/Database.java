package hw2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Database {
	Connection conn = null;
	public Database() {
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Assignment3?user=root&password=Yj26Xcco");
			if(conn == null) {
				System.out.println("it is null oh uh");
			}
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 public Boolean CheckUser(String username) {
		try {
		PreparedStatement ps = conn.prepareStatement( "SELECT *  FROM Usernames WHERE Names=?");
		ps.setString(1, username);
		 ResultSet results = ps.executeQuery();
		 if (results.next()) {
	 
	            return true;
	         }
		}catch(SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
		 return false;
		 
	}
	public Boolean CheckUP(String username, String password) {
		try {
			PreparedStatement ps = conn.prepareStatement( "SELECT password FROM Usernames WHERE Names=?");
			ps.setString(1, username);
			// set first variable in prepared statement
			 ResultSet results = ps.executeQuery();
			 if(results.getString("password").equals(null)){
		           return false;
			 }
			 return true;

			}catch(SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			}
			 return true;
	}
	public void RegisterUser(String username, String password) {
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Usernames(Names,password)"+" VALUES (?,?)");
			ps.setString(1, username);
			ps.setString(2, password);
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String GetUser(Integer ID) {
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT Names FROM Usernames WHERE UserId=?");
			ps.setInt(1, ID);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				return rs.getString("Names");
			}
			} catch (SQLException ex) {
		 		System.out.println("error");
			}
			return null;
	}
	public int GetID(String username) {
		try {
		PreparedStatement ps = conn.prepareStatement("SELECT UserID FROM Usernames WHERE Names=?");
		ps.setString(1, username);
		ResultSet rs = ps.executeQuery();
		if(rs.next()) {
			return rs.getInt("UserID");
		}
		} catch (SQLException ex) {
	 		System.out.println("error");
		}
		return -1;
		
	}
	public int LoginUser(String username, String password) {
		try {
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Usernames WHERE Names=? AND password=?");
		ps.setString(1, username); // set first variable in prepared statement
		ps.setString(2, password); 
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			return rs.getInt("UserID");
		}
	} catch (SQLException ex) {
		System.out.println("error");
	}
		return -1;
	}
	public void SetSearch(String input, Integer ID) {
		try { 
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Search(UserId,searchquerie)"+" VALUES (?,?)");
			ps.setInt(1, ID);
			ps.setString(2, input);
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public ArrayList<String> getSearch(Integer ID) {
		ArrayList<String> AllSearches = new ArrayList<String>();
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT searchquerie FROM Search WHERE UserId=?");
			ps.setInt(1, ID); // set first variable in prepared statement
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				 AllSearches.add(rs.getString("searchquerie"));
			}
		} catch (SQLException ex) {
			System.out.println("error");
		}
			return AllSearches;
		}
	
}
