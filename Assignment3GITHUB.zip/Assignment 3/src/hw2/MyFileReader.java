package hw2;

import java.io.BufferedReader;


import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import com.google.gson.Gson;



public class MyFileReader {
    public MyFileReader(){}
    public ArrayList<Cities2> getAllCities(){
    	URL url = getClass().getResource("/../../citylist.json");
    	try {
			BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
			Gson gson = new Gson();
			Cities2 [] c = gson.fromJson(br, Cities2[].class);
			ArrayList<Cities2> AllCities = new ArrayList<>(Arrays.asList(c));
			return AllCities;
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	return null;
    }
}


			
		
