package hw2;

import java.util.Comparator;

public class TempHighAscendingComparator implements Comparator<OpenWeather> {

	@Override
	public int compare(OpenWeather w0, OpenWeather w1) {
		return (int) (w0.getMain().getTempMax() - w1.getMain().getTempMax());
	}

}	
