package hw2;

import java.util.Comparator;

public class TempHighDescendingComparator implements Comparator<OpenWeather> {

	@Override
	public int compare(OpenWeather w0, OpenWeather w1) {
		return (int) (w1.getMain().getTempMax() - w0.getMain().getTempMax());
	}

}
