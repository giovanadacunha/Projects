package hw2;

import java.util.Comparator;

public class TempLowAscendingComparator implements Comparator<OpenWeather> {

	@Override
	public int compare(OpenWeather w0, OpenWeather w1) {
		return (int) (w0.getMain().getTempMin() - w1.getMain().getTempMax());
	}

}
