package hw2;

import java.util.Comparator;

public class TempLowDescendingComparator implements Comparator<OpenWeather> {

	@Override
	public int compare(OpenWeather w0, OpenWeather w1) {
		return (int) (w1.getMain().getTempMin() - w0.getMain().getTempMin());
	}
	
}
