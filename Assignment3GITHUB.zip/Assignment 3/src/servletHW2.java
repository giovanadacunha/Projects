

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import hw2.Database;
import java.text.DecimalFormat;
import java.util.ArrayList;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import hw2.Cities2;
import hw2.MyFileReader;
import hw2.OpenWeather;
/**
 * Servlet implementation class servletHW2
 */
@WebServlet("/servletHW2")

public class servletHW2 extends HttpServlet {
	MyFileReader w = new MyFileReader();
	
	private static final long serialVersionUID = 1L;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servletHW2() {
    	super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  int x = 0;
		  Database db = new Database();
		  ArrayList<Cities2> ArrayL = w.getAllCities();	
		  ArrayList<OpenWeather> OWarr = new ArrayList<OpenWeather>();
		  request.getSession();
		  HttpSession session = request.getSession();
		  session.setAttribute("Citieslist", ArrayL);
		  
		  DecimalFormat f = new DecimalFormat("#.##");
 		  String SearchBar = request.getParameter("city");
		  //i need to take out every space until i find a word
		  String Lat = request.getParameter("yes");
		  String Lon = request.getParameter("yes2");
		 
		  
		  Integer ID = (Integer) session.getAttribute("UserId");
			  //CREATE IF STATEMENT TO CHECK IF SEARCH BAR OR LAT/LON WERE CHOSEN
		  
	
		  if((SearchBar == "" || SearchBar == null) && ((Lat == "" || Lat == null) || (Lon == "" || Lon == null))) {
				  RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/index.jsp");
					dispatch.forward(request,response);
			  }
			 else if(SearchBar != "" && SearchBar != null) {
				 if(ID != null) {
					  db.SetSearch(SearchBar, ID);		  
				  }
				for(int i  = 0; i<ArrayL.size();i++) {
					if(ArrayL.get(i).getName().toLowerCase().contains(SearchBar.toLowerCase())) {
						x = 1;
		  					Integer identification = ArrayL.get(i).getId();
		  					String weblink = "http://api.openweathermap.org/data/2.5/weather?id="+identification + "&appid=39488d49cf22baba75bd6f4bac7f5c6f";
		  					URL openweather = new URL(weblink);
		  			        URLConnection ow = openweather.openConnection();
		  			        BufferedReader in = new BufferedReader(new InputStreamReader(ow.getInputStream()));
		  			      	Gson gson = new Gson();
		  					OpenWeather AllWeather = gson.fromJson(in, OpenWeather.class);
		  					OWarr.add(AllWeather);
						request.setAttribute("input", "city");
						request.setAttribute("array", OWarr);
						request.setAttribute("sort", "AZ");
						session.setAttribute("ARRAYSS", OWarr);

				
					}
				}
			}
			 else if(!(Lat == "" || Lat == null) || (Lon == "" || Lon == null)) {
				 
				 Double lat = Double.parseDouble(Lat);
				  Double lon = Double.parseDouble(Lon);
				  if(ID != null) {
					  db.SetSearch(f.format(lat)+","+f.format(lon), ID);		  
				  }
				  System.out.println(f.format(lat)+f.format(lon));
				 String weblink = "http://api.openweathermap.org/data/2.5/weather?lat="+ f.format(lat) + "&lon=" + f.format(lon)+ "&appid=39488d49cf22baba75bd6f4bac7f5c6f";
					URL openweather = new URL(weblink);
			        URLConnection ow = openweather.openConnection();
			        BufferedReader in = new BufferedReader(new InputStreamReader(ow.getInputStream()));
			      	Gson gson = new Gson();
			      	OpenWeather AllWeather = gson.fromJson(in, OpenWeather.class);
			      	if(AllWeather != null) {
			      		x++;
			      		OWarr.add(AllWeather);
							request.setAttribute("array", OWarr);
							request.setAttribute("input", "coord");
							request.setAttribute("sort", "AZ");							  
							session.setAttribute("ARRAYSS", OWarr);		
			      	}		
					}
		  	if(x==0) {
		  		request.setAttribute("input", "error");
			
				
			}
		  	RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/results.jsp");
			dispatch.forward(request,response);
		}
	
		// TODO Auto-generated method stub
		

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	

}
